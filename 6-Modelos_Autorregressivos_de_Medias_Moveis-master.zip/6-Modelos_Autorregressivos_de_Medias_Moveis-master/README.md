# Médias Móveis e Modelos Autorregressivos de Médias Móveis
Material didático para aula 6 de Econometria Avançada- Séries Temporais na USJT.
